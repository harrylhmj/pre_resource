.. _mod_rx_engine:

=============
``rx_engine``
=============

``rx_engine`` manages receive datapath operations including descriptor dequeue and fetch via DMA, packet reception, data writeback via DMA, and completion enqueue and writeback via DMA.  It also handles PTP timestamps for inclusion in completion records.
