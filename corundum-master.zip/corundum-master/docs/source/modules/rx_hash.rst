.. _mod_rx_hash:

===========
``rx_hash``
===========

``rx_hash`` implements flow hashing on the receive path.  It extracts IP addresses and ports from packet headers and computes a 32-bit Toeplitz flow hash.
