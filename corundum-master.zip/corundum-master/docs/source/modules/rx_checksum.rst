.. _mod_rx_checksum:

===============
``rx_checksum``
===============

``rx_checksum`` implements the receive checksum offloading support.  It computes 16 bit checksum of Ethernet frame payload to aid in IP checksum offloading by the host network stack.
