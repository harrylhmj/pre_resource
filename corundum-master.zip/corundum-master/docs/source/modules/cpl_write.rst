.. _mod_cpl_write:

=============
``cpl_write``
=============

``cpl_write`` manages operations associated with completion writeback.  It is responsible for enqueuing completion and event records into the completion queue managers and writing records into host memory via DMA.
