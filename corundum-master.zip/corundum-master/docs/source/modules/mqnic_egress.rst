.. _mod_mqnic_egress:

================
``mqnic_egress``
================

``mqnic_egress`` implements egress processing on the transmit side.  This consists of:

1. Transmit checksum offloading

``mqnic_egress`` integrates the following modules:

* :ref:`mod_tx_checksum`: transmit checksum offloading
