.. _mod_tx_checksum:

===============
``tx_checksum``
===============

``tx_checksum`` implements the transmit checksum offloading support.  It computes 16 bit checksum of frame data with specified start offset, then inserts computed checksum at the position specified by the host network stack.
