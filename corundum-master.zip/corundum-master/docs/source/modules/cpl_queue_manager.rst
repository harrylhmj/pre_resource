.. _mod_cpl_queue_manager:

=====================
``cpl_queue_manager``
=====================

``cpl_queue_manager`` implements