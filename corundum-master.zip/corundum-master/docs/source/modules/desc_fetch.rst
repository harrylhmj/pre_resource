.. _mod_desc_fetch:

==============
``desc_fetch``
==============

``desc_fetch`` manages operations associated with fetching descriptors.  It is responsible for dequeuing descriptors from the queue managers and reading descriptors from host memory via DMA.
